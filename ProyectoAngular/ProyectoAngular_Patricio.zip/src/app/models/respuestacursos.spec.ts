import { Respuestacursos } from './respuestacursos';

describe('Respuestacursos', () => {
  it('should create an instance', () => {
    expect(new Respuestacursos()).toBeTruthy();
  });
});

import { Respuetagrupos } from './respuetagrupos';

describe('Respuetagrupos', () => {
  it('should create an instance', () => {
    expect(new Respuetagrupos()).toBeTruthy();
  });
});

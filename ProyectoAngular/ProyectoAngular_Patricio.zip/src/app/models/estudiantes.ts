export class Estudiantes {

    id: string = "";
    cedula: string = "";
    correoelectronico: string = "";
    telefono: string = "";
    telefonocelular: string = "";
    fechanacimiento: string = "";
    sexo: string = "";
    direccion: string = "";
    nombre: string = "";
    apellidopaterno: string = "";
    apellidomaterno: string = "";
    idCarreras: string = "";
    usuario: string = "";
    nacionalidad: string = "";


}

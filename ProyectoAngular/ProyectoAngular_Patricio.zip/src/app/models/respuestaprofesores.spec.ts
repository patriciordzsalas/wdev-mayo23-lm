import { Respuestaprofesores } from './respuestaprofesores';

describe('Respuestaprofesores', () => {
  it('should create an instance', () => {
    expect(new Respuestaprofesores()).toBeTruthy();
  });
});

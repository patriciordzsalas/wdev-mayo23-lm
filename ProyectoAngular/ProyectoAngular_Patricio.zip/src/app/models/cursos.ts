export class Cursos {
    id: string = "";
    nombre: string = "";
    descripcion: string = "";
    tiempo: string = "";
    usuario: string = "";

}

import { Grupos } from "./grupos";
export class Respuetagrupos {

    code: number = 0;
    message: string = "";
    data: Grupos[] = [];

}


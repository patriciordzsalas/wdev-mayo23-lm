import { Respuestausuarios } from './respuestausuarios';

describe('Respuestausuarios', () => {
  it('should create an instance', () => {
    expect(new Respuestausuarios()).toBeTruthy();
  });
});

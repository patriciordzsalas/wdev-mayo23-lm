import { Profesores } from "./profesores";

export class Respuestaprofesores {

    code: number = 0;
    message: string = "";
    data: Profesores[] = [];
}

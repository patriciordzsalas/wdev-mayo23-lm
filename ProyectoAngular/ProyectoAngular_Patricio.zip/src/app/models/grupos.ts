export class Grupos {

    id: string = "";
    nombre: string = "";

}
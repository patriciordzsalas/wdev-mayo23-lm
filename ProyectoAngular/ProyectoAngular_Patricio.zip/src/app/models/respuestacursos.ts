import { Cursos } from "./cursos";

export class Respuestacursos {
    
            code: number = 0;
            message: string = "";
            data: Cursos[] = [];
          
}

import { Estudiantes } from "./estudiantes";

export class Respuestaestudiantes {

    code: number = 0;
    message: string = "";
    data: Estudiantes[] = [];

}

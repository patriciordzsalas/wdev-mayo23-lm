export class Usuarios {
   
    id: string = "";
    name: string = "";
    email: string = "";
    password: string = "";

}


// {"id":"464","
// name":"JAD PRUEBA",
// "email":"prueba12345@prueba.com",
// "password":"f2d5eb2821752a6e46224c30e4c98c98"}
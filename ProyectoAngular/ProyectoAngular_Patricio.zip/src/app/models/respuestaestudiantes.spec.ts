import { Respuestaestudiantes } from './respuestaestudiantes';

describe('Respuestaestudiantes', () => {
  it('should create an instance', () => {
    expect(new Respuestaestudiantes()).toBeTruthy();
  });
});

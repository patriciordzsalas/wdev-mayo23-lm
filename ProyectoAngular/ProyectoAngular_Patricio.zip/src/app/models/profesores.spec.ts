import { Profesores } from './profesores';

describe('Profesores', () => {
  it('should create an instance', () => {
    expect(new Profesores()).toBeTruthy();
  });
});

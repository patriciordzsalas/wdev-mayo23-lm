import { Usuarios } from "./usuarios";

export class Respuestausuarios {

            code: number = 0;
            message: string = "";
            data: Usuarios[] = [];

}


